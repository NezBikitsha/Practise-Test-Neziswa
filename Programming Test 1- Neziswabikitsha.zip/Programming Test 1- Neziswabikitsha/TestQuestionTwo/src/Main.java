//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        String[] strArr = new String[50];
    }

    String[] strArr;

    {
        strArr = new String[50];
        for (int i = strArr . length - 1; i >= 0; i --) {
            strArr [ i ] = "b" + ( i - 1) ;
        }
    }



        System.out.println(;


    int rand;
    int [] intArr = new int [50];
    for (int i = 0; i < intArr . length ; i ++)

    {
        rand = new int[];
        intArr[i] = rand.nextInt(50);
    }
        }

